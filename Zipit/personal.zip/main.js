const intro = document.getElementById("intro");
    const main = document.getElementById("main");

    function startUp(){
        setTimeout(() =>{
            intro.style.display = "none";
            main.style.display = "block";
        }, 5000);
    }
    
    function extractZip() {
      const fileInput = document.getElementById('zipFileInput');
      const file = fileInput.files[0];

      if (file) {
        const reader = new FileReader();
        reader.onload = function (event) {
          const arrayBuffer = event.target.result;
          const jszip = new JSZip();

          jszip.loadAsync(arrayBuffer).then(function (zip) {
            zip.forEach(function (relativePath, zipEntry) {
              zipEntry.async('arraybuffer').then(function (data) {
                // Create a download link for each extracted file
                const blob = new Blob([data]);
                const downloadLink = document.createElement('a');
                downloadLink.href = URL.createObjectURL(blob);
                downloadLink.download = relativePath;
                downloadLink.innerHTML = `Download ${relativePath}`;
                document.getElementById('output').appendChild(downloadLink);
              });
            });
          });
        };

        reader.readAsArrayBuffer(file);
      }
    }